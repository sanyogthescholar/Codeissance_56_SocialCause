// import * as React from 'react';
// import {Switch,Route} from 'react-router-dom'
// import Admin from './Admin'
// import SimpleUser from './SimpleUser'
// import CommanLogin from './CommanLogin'
// import  '../CSS/Tabs.css'

// export default function Tabs() {

//   return (
//   <>

//     <div  className="tabs">
//     <Switch>
//     <Route exact path="/Tabs"><SimpleUser/></Route>
//      <Route exact path="/Admin"><Admin/></Route>
//      <Route exact path="/CommanLogin"><CommanLogin/></Route>
//       </Switch>
//     </div>
//     </>
//   );
// }




