import i4 from './images/i4.jpg'
import i5 from './images/i5 - Copy.jpg'
import i6 from './images/i6.jpg';

const data = [
    {
        iId: 4,
        Image: i4,
        name: "Raddiwala",
        class:"flip-left",
    },
    {
        iId: 5,
        Image: i5,
        name: "Bhajiwala",
        class:"flip-right",
    },
    {
        iId: 7,
        Image: i6,
        name: "Others",
        class:"flip-right",
    }
]

export default data;